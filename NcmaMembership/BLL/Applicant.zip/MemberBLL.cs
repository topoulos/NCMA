﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Objects;

namespace NcmaMembership.BLL
{
    public static class MemberBLL
    {
        public static ObjectSet<member> GetMembers()
        {
            MyNcmaEntities db = new MyNcmaEntities();
            return db.members;
        }
    }
}
