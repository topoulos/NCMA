﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NcmaMembership.DAL;
using System.Data;

namespace NcmaMembership.BLL
{
    public class MemberCert
    {
        public int MemberID { get; set; }
        public int DojoID { get; set; }
        public int CertificateTypeID { get; set; }
        public string RankText { get; set; }
        public int InstructorID { get; set; }
        public int InstructorTypeID { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ThruDate { get; set; }
        public bool Completed { get; set; }
        public int TourneyID { get; set; }

        public bool Insert()
        {
            return DAL.DAL.InsertRecordIntoTable(this, "id", "sp_membercertsInsert");
        }

        public bool Update()
        {
            return DAL.DAL.UpdateRecordInTable(this, "id", "sp_membercertsUpdate");
        }

        public bool Delete(int ID)
        {
            return DAL.DAL.DeleteRecordFromTableWithID(ID, "sp_membercertsUpdate");
        }

        public List<MemberCert> GetAll()
        {
            DataTable tbl = DAL.DAL.GetAllRecordsFromTable("membercerts");
            return MemberCertHelper.FromTableToList(tbl);
        }

        public List<MemberCert> GetPage(int pageSize, int index, List<string> fieldsToFilter, string filterTextToFind, string fieldToSort)
        {
            DataTable tbl = DAL.DAL.GetPagedRecordsFromTable("membercerts", "ID", pageSize, index, fieldToSort, fieldsToFilter, "contains", filterTextToFind);
            return MemberCertHelper.FromTableToList(tbl);
        }

        public MemberCert GetSingle(int ID)
        {
            DataTable tbl = DAL.DAL.GetRecordFromTableByID(ID, "membercerts");
            return MemberCertHelper.FromTableToList(tbl).FirstOrDefault();
        }
    }

    internal class MemberCertHelper
    {
        internal static List<MemberCert> FromTableToList(DataTable tbl)
        {
            IList<MemberCert> data = tbl.AsEnumerable().Select(row =>
                new MemberCert
                {
                    MemberID = row.Field<int>("MemberID"),
                    DojoID = row.Field<int>("DojoID"),
                    CertificateTypeID = row.Field<int>("CertificateTypeID"),
                    RankText = row.Field<string>("RankText"),
                    InstructorID = row.Field<int>("InstructorID"),
                    InstructorTypeID = row.Field<int>("InstructorTypeID"),
                    FromDate = row.Field<DateTime>("FromDate"),
                    ThruDate = row.Field<DateTime>("ThruDate"),
                    Completed = row.Field<bool>("Completed"),
                    TourneyID = row.Field<int>("TourneyID")
                }).ToList();
            return (List<MemberCert>)data;
        }
    }
}

