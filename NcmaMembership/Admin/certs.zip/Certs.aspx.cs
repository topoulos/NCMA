﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NcmaMembership
{
    public partial class Certs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        // Handles the data callback 
        protected void ASPxGridView1_CustomDataCallback(object sender, DevExpress.Web.ASPxGridView.ASPxGridViewCustomDataCallbackEventArgs e)
        {
            MyNcmaEntities context = new MyNcmaEntities();
            if (ASPxGridView1.IsEditing)
            {
                int retParam = 0;
                int.TryParse(e.Parameters, out retParam);
                if (retParam != 0)
                {
                    var query1 = from m in context.members
                                where m.ID == retParam
                                select m;

                    member thisMember = query1.ToList().FirstOrDefault();

                    var query2 = from m in context.dojoinstructors
                                 where m.DojoID == thisMember.DojoID
                                 select m.InstructorID;

                    int instID = query2.ToList().FirstOrDefault() == null ? 0 : query2.ToList().FirstOrDefault().Value;

                    string retVal = string.Format("{0}|{1}", thisMember.DojoID, instID);

                    e.Result = retVal; 
                    
 
                }
            }
        }

     


   
    }
}